export const requestwe = $.ajax({
  type: "GET",
  url: "C:/UwAmp/www/ProjetS5/data/survey_results_WE.json"
});

export const requestna = $.ajax({
  type: "GET",
  url: "C:/UwAmp/www/ProjetS5/data/survey_results_NA.json"
});
